var server = require("../server");

exports.getPlaintext = function(request, response) {
    var data = request.query.data;

    server.dbprovider.save("intelligence", { stuff : data }, function(error, json) {
        response.redirect("/dummy.html");
    });
}

exports.showStuff = function(request, response) {
    itemz = [];

    server.dbprovider.findAll("intelligence", function(error, json) {
        if (error != null) {
            response.send("MongoDB ERROR: " + error);			
        }
        response.send(json);
    });
}

exports.getEncrypted = function(request, response) {
    /*
    var uname = request.query.uname;
    var passwd = request.query.passwd;

    server.dbprovider.save("users", {name : uname , password : passwd}, function(error, item) {
        if (error != null) {
        response.send("MongoDB ERROR: " + error);           
        }           
        response.send("Thank you!");
    });
    */
    response.send("TODO");
}
