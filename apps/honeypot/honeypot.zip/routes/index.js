/*
* GET index page
*/

exports.index = function(request, response) {
    var data = request.query.data;
    response.redirect("/plain?data="+ data);
}
