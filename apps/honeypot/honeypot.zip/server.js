var express = require("express"),
	http = require("http"),
	path = require("path"),
	bodyParser = require("body-parser"),
	methodOverride = require("method-override"),
	errorhandler = require("errorhandler"),
	routes = require("./routes"),
	getter = require("./routes/getter"),
	port = process.argv[2] || 8888,
	mongoProvider = require("./dbproviders/mongoProvider").mongoProvider;
	
var server = express();

server.use(express.static(__dirname + "/public/client"));
server.use(methodOverride());
server.use(errorhandler());
server.use(bodyParser.urlencoded({ extended: true }));
server.use(bodyParser.json());

// Init db provider --------------------------------
var dbName = "honeypot";
var dbprovider = new mongoProvider(dbName,"localhost", 27017);

// Assign routes -----------------------------------
server.get("/", routes.index);
server.get("/plain", getter.getPlaintext);
server.get("/encrypted", getter.getEncrypted);
server.get("/show", getter.showStuff);
//--------------------------------------------------

// Start the server --------------------------------
http.createServer(server).listen(port, function() {	
	console.log("Server started on port: " + port);
});

exports.dbprovider = dbprovider;
