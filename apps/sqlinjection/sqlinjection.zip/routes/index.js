/*
* GET index page
*/

exports.index = function(request, response) {
	response.redirect("/login.html");
}
