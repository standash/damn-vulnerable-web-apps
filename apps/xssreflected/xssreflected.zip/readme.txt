1. Use "package.json" to add new dependencies;
2. To install all node.js dependencies type:
	-> npm install -d
