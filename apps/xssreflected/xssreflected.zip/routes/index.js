/*
* Dummy page
*/
exports.index = function(request, response) {
	response.send("It works!");
}
