var express = require("express"),
	http = require("http"),
	path = require("path"),
	bodyParser = require("body-parser"),
	methodOverride = require("method-override"),
	errorhandler = require("errorhandler"),
	routes = require("./routes"),
	comments = require("./routes/comments");
	port = process.argv[2] || 8888;
	
var server = express();

server.use(express.static(__dirname + "/public/client"));

// Init db provider --------------------------------
server.use(methodOverride());
server.use(errorhandler());
server.use(bodyParser.urlencoded({ extended: true }));
server.use(bodyParser.json());

// Assign routes -----------------------------------
server.get("/", routes.index);
server.post("/page.html", comments.addComment)
//--------------------------------------------------

// Start the server --------------------------------
http.createServer(server).listen(port, function() {	
	console.log("Server started on port: " + port);
});

exports.server = server;
